"""Main module."""
import logging
import asyncio

import cfg4py
from sanic import Sanic, response

from chatter.config import get_config_dir
from chatter.dingtalk import ding
from chatter.gpt import Bot

application = Sanic("chatter")
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

bot: Bot

"""
{
    "conversationId": "xxx",
    "atUsers": [
        {
            "dingtalkId": "xxx",
            "staffId":"xxx"
        }
    ],
    "chatbotCorpId": "dinge8a565xxxx",
    "chatbotUserId": "$:LWCP_v1:$Cxxxxx",
    "msgId": "msg0xxxxx",
    "senderNick": "杨xx",
    "isAdmin": true,
    "senderStaffId": "user123",
    "sessionWebhookExpiredTime": 1613635652738,
    "createAt": 1613630252678,
    "senderCorpId": "dinge8a565xxxx",
    "conversationType": "2",
    "senderId": "$:LWCP_v1:$Ff09GIxxxxx",
    "conversationTitle": "机器人测试-TEST",
    "isInAtList": true,
    "sessionWebhook": "https://oapi.dingtalk.com/robot/sendBySession?session=xxxxx",
    "text": {
        "content": " 你好"
    },
    "msgtype": "text"
}
"""
@application.route("/abcde/chatter", methods=["GET", "POST"])
async def root(request):
    global bot

    params = request.json or {}
    question = params.get("text", {}).get("content", "")
    sender_id = params.get("senderId", "")
    nickname = params.get("senderNick", "")
    logger.info("chat with %s, received:\n%s", nickname, params)

    if len(question) == 0:
        return response.text("ok")

    msg = await bot.ask(question, session_id=sender_id)
    logger.info("got answer from GPT:%s", msg)
    await ding(msg)
    return response.text("OK")

@application.route("/abcde/status")
async def status(request):
    return response.text("OK")

@application.listener("before_server_start")
async def application_init(app, *args):
    global bot

    cfg4py.init(get_config_dir())
    while True:
        try:
            bot = Bot()
            break
        except Exception as e:
            logger.error("init bot failed, retry in 5s", exc_info=e)
            await asyncio.sleep(5)


@application.listener("after_server_stop")
async def application_exit(app, *args):
    pass


def start(port=2130):
    application.config.RESPONSE_TIMEOUT = 60 * 10

    application.run(host="0.0.0.0", port=port, register_sys_signals=True, workers=1)
    logger.info("chatter server stopped")
