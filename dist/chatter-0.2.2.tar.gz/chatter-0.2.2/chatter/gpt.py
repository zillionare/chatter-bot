import asyncio
import logging

import arrow
from async_timeout import timeout
from revChatGPT.V2 import Chatbot

logger = logging.getLogger(__name__)

class Bot:
    def __init__(self) -> None:
        logger.info("logging to chatGPT")
        self.gpt = Chatbot(
            "belvaaaan@gmail.com",
            "woaiwo??123",
        )

        if self.gpt.api_key is None:
            logger.error("login failed")
            raise Exception("login failed")

        
        self.chat_sessions = {}

    async def ask(self, prompt: str, session_id: str, time_out:int=10):
        self.chat_sessions.update({session_id: arrow.now()})

        rutter = []
        try:
            async with timeout(time_out) as cm:
                async for line in self.gpt.ask(prompt=prompt, conversation_id=session_id):
                    result = line["choices"][0]["text"].replace("<|im_end|>", "")
                    rutter.append(result)
                    cm.shift(1)
        except Exception as e:
            logger.exception(e)
            return "机器人忙，请稍候重试"
                
        if len(rutter) == 0:
            return "机器人忙，请稍候重试。"
        
        answer = "".join(rutter)
        logger.info("got answer from GPT:%s", answer)
        return answer
