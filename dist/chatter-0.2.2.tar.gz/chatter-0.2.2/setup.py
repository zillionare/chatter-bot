# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['chatter', 'chatter.config']

package_data = \
{'': ['*']}

install_requires = \
['arrow>=1.2.3,<2.0.0',
 'async-timeout>=4.0.2,<5.0.0',
 'cfg4py>=0.9.4,<0.10.0',
 'openai>=0.26.5,<0.27.0',
 'psutil>=5.9.4,<6.0.0',
 'revChatGPT>=2.2.0,<3.0.0',
 'sanic>=22.12.0,<23.0.0',
 'tqdm>=4.64.1,<5.0.0']

entry_points = \
{'console_scripts': ['chatter = chatter.cli:main']}

setup_kwargs = {
    'name': 'chatter',
    'version': '0.2.2',
    'description': '',
    'long_description': None,
    'author': 'aaron yang',
    'author_email': 'aaron_yang@jieyu.ai',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
